package com.romino.gestionnaireultra

import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

object FileOperations {

    fun copyRecursively(source: File, targetDir: File): Boolean {
        return try {
            val target = File(targetDir, source.name)
            source.copyRecursively(target, overwrite = true)
        } catch (e: Exception) {
            false
        }
    }

    fun moveRecursively(source: File, targetDir: File): Boolean {
        return try {
            val target = File(targetDir, source.name)
            val copied = source.copyRecursively(target, overwrite = true)
            if (copied) source.deleteRecursively() else false
        } catch (e: Exception) {
            false
        }
    }

    fun deleteRecursively(file: File): Boolean {
        return try {
            file.deleteRecursively()
        } catch (e: Exception) {
            false
        }
    }

    fun rename(file: File, newName: String): File? {
        val target = File(file.parentFile, newName)
        return if (file.renameTo(target)) target else null
    }

    fun createFolder(parent: File, name: String): File? {
        val newDir = File(parent, name)
        return if (newDir.mkdirs()) newDir else null
    }

    fun createFile(parent: File, name: String): File? {
        val newFile = File(parent, name)
        return try {
            if (newFile.createNewFile()) newFile else null
        } catch (e: Exception) {
            null
        }
    }

    fun folderSize(file: File): Long {
        if (!file.isDirectory) return file.length()
        var size = 0L
        file.listFiles()?.forEach { child ->
            size += if (child.isDirectory) folderSize(child) else child.length()
        }
        return size
    }

    fun searchFiles(root: File, query: String, results: MutableList<File>, limit: Int = 500) {
        if (results.size >= limit) return
        val children = root.listFiles() ?: return
        for (child in children) {
            if (results.size >= limit) return
            if (child.name.contains(query, ignoreCase = true)) {
                results.add(child)
            }
            if (child.isDirectory) {
                searchFiles(child, query, results, limit)
            }
        }
    }

    fun zipFiles(files: List<File>, destZip: File) {
        ZipOutputStream(FileOutputStream(destZip)).use { zos ->
            files.forEach { file ->
                addToZip(file, file.name, zos)
            }
        }
    }

    private fun addToZip(file: File, entryName: String, zos: ZipOutputStream) {
        if (file.isDirectory) {
            val children = file.listFiles()
            if (children.isNullOrEmpty()) {
                zos.putNextEntry(ZipEntry("$entryName/"))
                zos.closeEntry()
            } else {
                children.forEach { child ->
                    addToZip(child, "$entryName/${child.name}", zos)
                }
            }
        } else {
            zos.putNextEntry(ZipEntry(entryName))
            FileInputStream(file).use { it.copyTo(zos) }
            zos.closeEntry()
        }
    }

    fun unzip(zipFile: File, destDir: File) {
        ZipInputStream(FileInputStream(zipFile)).use { zis ->
            var entry = zis.nextEntry
            while (entry != null) {
                val outFile = File(destDir, entry.name)
                if (entry.isDirectory) {
                    outFile.mkdirs()
                } else {
                    outFile.parentFile?.mkdirs()
                    FileOutputStream(outFile).use { zis.copyTo(it) }
                }
                zis.closeEntry()
                entry = zis.nextEntry
            }
        }
    }

    fun isTextReadable(file: File): Boolean {
        return file.length() < 2_000_000
    }
}
