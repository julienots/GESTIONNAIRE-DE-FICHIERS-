package com.romino.gestionnaireultra

import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class FileItem(val file: File) {
    val name: String get() = file.name
    val isDirectory: Boolean get() = file.isDirectory
    val isHidden: Boolean get() = file.isHidden || file.name.startsWith(".")
    val lastModified: Long get() = file.lastModified()
    val extension: String get() = file.extension.lowercase()

    fun size(): Long = if (isDirectory) 0L else file.length()

    fun childCount(): Int = if (isDirectory) (file.listFiles()?.size ?: 0) else 0
}

enum class FileCategory { FOLDER, IMAGE, VIDEO, AUDIO, TEXT, DOCUMENT, ARCHIVE, APK, OTHER }

fun FileItem.category(): FileCategory {
    if (isDirectory) return FileCategory.FOLDER
    return when (extension) {
        "jpg", "jpeg", "png", "gif", "bmp", "webp" -> FileCategory.IMAGE
        "mp4", "mkv", "avi", "mov", "webm", "3gp" -> FileCategory.VIDEO
        "mp3", "wav", "ogg", "flac", "m4a", "aac" -> FileCategory.AUDIO
        "txt", "md", "json", "xml", "kt", "java", "py", "js", "html", "css", "csv", "log", "gradle", "yml", "yaml" -> FileCategory.TEXT
        "pdf", "doc", "docx", "xls", "xlsx", "ppt", "pptx" -> FileCategory.DOCUMENT
        "zip", "rar", "7z", "tar", "gz" -> FileCategory.ARCHIVE
        "apk" -> FileCategory.APK
        else -> FileCategory.OTHER
    }
}

fun FileCategory.emoji(): String = when (this) {
    FileCategory.FOLDER -> "\uD83D\uDCC1"
    FileCategory.IMAGE -> "\uD83D\uDDBC\uFE0F"
    FileCategory.VIDEO -> "\uD83C\uDFAC"
    FileCategory.AUDIO -> "\uD83C\uDFB5"
    FileCategory.TEXT -> "\uD83D\uDCDD"
    FileCategory.DOCUMENT -> "\uD83D\uDCC4"
    FileCategory.ARCHIVE -> "\uD83D\uDDDC\uFE0F"
    FileCategory.APK -> "\uD83D\uDCE6"
    FileCategory.OTHER -> "\uD83D\uDCC4"
}

fun humanReadableSize(bytes: Long): String {
    if (bytes < 1024) return "$bytes o"
    val units = arrayOf("Ko", "Mo", "Go", "To")
    var value = bytes / 1024.0
    var unitIndex = 0
    while (value >= 1024 && unitIndex < units.size - 1) {
        value /= 1024.0
        unitIndex++
    }
    return String.format(Locale.FRANCE, "%.1f %s", value, units[unitIndex])
}

fun formatDate(timestamp: Long): String {
    val sdf = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.FRANCE)
    return sdf.format(Date(timestamp))
}
