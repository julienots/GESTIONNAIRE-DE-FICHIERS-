package com.romino.gestionnaireultra.ui

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.romino.gestionnaireultra.FileManagerViewModel
import com.romino.gestionnaireultra.humanReadableSize

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun StorageInfoScreen(viewModel: FileManagerViewModel, onBack: () -> Unit) {
    val (total, used, free) = viewModel.storageStats()
    val usedFraction = if (total > 0) used.toFloat() / total.toFloat() else 0f

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Stockage") },
                navigationIcon = { IconButton(onClick = onBack) { Text("\u2190") } }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(24.dp)
        ) {
            Text("Espace total : ${humanReadableSize(total)}", style = MaterialTheme.typography.bodyLarge)
            Spacer(modifier = Modifier.height(8.dp))
            Text("Espace utilise : ${humanReadableSize(used)}", style = MaterialTheme.typography.bodyLarge)
            Spacer(modifier = Modifier.height(8.dp))
            Text("Espace libre : ${humanReadableSize(free)}", style = MaterialTheme.typography.bodyLarge)
            Spacer(modifier = Modifier.height(16.dp))
            LinearProgressIndicator(
                progress = usedFraction,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(12.dp)
            )
        }
    }
}
