package com.romino.gestionnaireultra

import android.app.Application
import android.os.Environment
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

enum class SortMode { NAME, DATE, SIZE, TYPE }
enum class ViewMode { LIST, GRID }
enum class ClipboardMode { COPY, CUT }

class FileManagerViewModel(application: Application) : AndroidViewModel(application) {

    private val rootDir: File = Environment.getExternalStorageDirectory()
    private val prefs = application.getSharedPreferences("gestionnaire_ultra", 0)

    var currentDir by mutableStateOf(rootDir)
        private set

    var items by mutableStateOf<List<FileItem>>(emptyList())
        private set

    var selection by mutableStateOf<Set<String>>(emptySet())
        private set

    var sortMode by mutableStateOf(SortMode.NAME)
    var sortAscending by mutableStateOf(true)
    var showHidden by mutableStateOf(false)
    var viewMode by mutableStateOf(ViewMode.LIST)
    var searchQuery by mutableStateOf("")

    var isLoading by mutableStateOf(false)
        private set

    var clipboard by mutableStateOf<Pair<List<File>, ClipboardMode>?>(null)
        private set

    var favorites by mutableStateOf(loadFavorites())
        private set

    var statusMessage by mutableStateOf<String?>(null)

    init {
        loadDirectory(rootDir)
    }

    private fun loadFavorites(): List<File> {
        val raw = prefs.getStringSet("favorites", emptySet()) ?: emptySet()
        return raw.map { File(it) }.filter { it.exists() }
    }

    private fun saveFavorites() {
        prefs.edit().putStringSet("favorites", favorites.map { it.absolutePath }.toSet()).apply()
    }

    fun toggleFavorite(dir: File) {
        favorites = if (favorites.any { it.absolutePath == dir.absolutePath }) {
            favorites.filterNot { it.absolutePath == dir.absolutePath }
        } else {
            favorites + dir
        }
        saveFavorites()
    }

    fun isFavorite(dir: File) = favorites.any { it.absolutePath == dir.absolutePath }

    fun loadDirectory(dir: File) {
        currentDir = dir
        clearSelection()
        refresh()
    }

    fun refresh() {
        viewModelScope.launch {
            isLoading = true
            val list = withContext(Dispatchers.IO) {
                val children = currentDir.listFiles()?.toList() ?: emptyList()
                var filtered = children.map { FileItem(it) }
                if (!showHidden) filtered = filtered.filterNot { it.isHidden }
                sortList(filtered)
            }
            items = list
            isLoading = false
        }
    }

    private fun sortList(list: List<FileItem>): List<FileItem> {
        val comparator: Comparator<FileItem> = when (sortMode) {
            SortMode.NAME -> compareBy { it.name.lowercase() }
            SortMode.DATE -> compareBy { it.lastModified }
            SortMode.SIZE -> compareBy { it.size() }
            SortMode.TYPE -> compareBy { it.extension }
        }
        val finalComparator = if (sortAscending) comparator else comparator.reversed()
        return list.sortedWith(compareByDescending<FileItem> { it.isDirectory }.then(finalComparator))
    }

    fun navigateInto(item: FileItem) {
        if (item.isDirectory) loadDirectory(item.file)
    }

    fun navigateUp(): Boolean {
        val parent = currentDir.parentFile
        return if (parent != null && currentDir.absolutePath != rootDir.absolutePath && parent.canRead()) {
            loadDirectory(parent)
            true
        } else false
    }

    fun navigateToRoot() = loadDirectory(rootDir)

    fun toggleSelect(item: FileItem) {
        selection = if (selection.contains(item.file.absolutePath)) {
            selection - item.file.absolutePath
        } else {
            selection + item.file.absolutePath
        }
    }

    fun clearSelection() {
        selection = emptySet()
    }

    fun selectedFiles(): List<File> = items.filter { selection.contains(it.file.absolutePath) }.map { it.file }

    fun deleteSelected() {
        viewModelScope.launch {
            val files = selectedFiles()
            withContext(Dispatchers.IO) {
                files.forEach { FileOperations.deleteRecursively(it) }
            }
            statusMessage = "${files.size} element(s) supprime(s)"
            clearSelection()
            refresh()
        }
    }

    fun copySelectedToClipboard() {
        val files = selectedFiles()
        clipboard = files to ClipboardMode.COPY
        statusMessage = "${files.size} element(s) copie(s)"
        clearSelection()
    }

    fun cutSelectedToClipboard() {
        val files = selectedFiles()
        clipboard = files to ClipboardMode.CUT
        statusMessage = "${files.size} element(s) coupe(s)"
        clearSelection()
    }

    fun pasteClipboard() {
        val clip = clipboard ?: return
        viewModelScope.launch {
            withContext(Dispatchers.IO) {
                clip.first.forEach { file ->
                    if (clip.second == ClipboardMode.COPY) {
                        FileOperations.copyRecursively(file, currentDir)
                    } else {
                        FileOperations.moveRecursively(file, currentDir)
                    }
                }
            }
            if (clip.second == ClipboardMode.CUT) clipboard = null
            statusMessage = "Colle avec succes"
            refresh()
        }
    }

    fun renameFile(file: File, newName: String) {
        viewModelScope.launch {
            withContext(Dispatchers.IO) { FileOperations.rename(file, newName) }
            refresh()
        }
    }

    fun createFolder(name: String) {
        viewModelScope.launch {
            withContext(Dispatchers.IO) { FileOperations.createFolder(currentDir, name) }
            refresh()
        }
    }

    fun createNewFile(name: String) {
        viewModelScope.launch {
            withContext(Dispatchers.IO) { FileOperations.createFile(currentDir, name) }
            refresh()
        }
    }

    fun compressSelected(zipName: String) {
        viewModelScope.launch {
            val files = selectedFiles()
            withContext(Dispatchers.IO) {
                val dest = File(currentDir, if (zipName.endsWith(".zip")) zipName else "$zipName.zip")
                FileOperations.zipFiles(files, dest)
            }
            clearSelection()
            statusMessage = "Archive creee"
            refresh()
        }
    }

    fun extractZip(file: File) {
        viewModelScope.launch {
            withContext(Dispatchers.IO) {
                val destDir = File(currentDir, file.nameWithoutExtension)
                destDir.mkdirs()
                FileOperations.unzip(file, destDir)
            }
            statusMessage = "Extraction terminee"
            refresh()
        }
    }

    fun search(query: String, onResult: (List<FileItem>) -> Unit) {
        viewModelScope.launch {
            isLoading = true
            val results = withContext(Dispatchers.IO) {
                val found = mutableListOf<File>()
                FileOperations.searchFiles(currentDir, query, found)
                found.map { FileItem(it) }
            }
            isLoading = false
            onResult(results)
        }
    }

    fun storageStats(): Triple<Long, Long, Long> {
        val total = rootDir.totalSpace
        val free = rootDir.freeSpace
        val used = total - free
        return Triple(total, used, free)
    }
}
