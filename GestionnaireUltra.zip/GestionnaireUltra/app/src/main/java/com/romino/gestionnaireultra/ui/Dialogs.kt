package com.romino.gestionnaireultra.ui

import androidx.compose.foundation.layout.Column
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import com.romino.gestionnaireultra.FileItem
import com.romino.gestionnaireultra.FileOperations
import com.romino.gestionnaireultra.category
import com.romino.gestionnaireultra.emoji
import com.romino.gestionnaireultra.formatDate
import com.romino.gestionnaireultra.humanReadableSize

@Composable
fun NameInputDialog(
    title: String,
    initialValue: String = "",
    onConfirm: (String) -> Unit,
    onDismiss: () -> Unit
) {
    var text by remember { mutableStateOf(initialValue) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = {
            OutlinedTextField(
                value = text,
                onValueChange = { text = it },
                singleLine = true
            )
        },
        confirmButton = {
            TextButton(onClick = {
                if (text.isNotBlank()) {
                    onConfirm(text.trim())
                    onDismiss()
                }
            }) { Text("Valider") }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Annuler") }
        }
    )
}

@Composable
fun PropertiesDialog(item: FileItem, onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("${item.category().emoji()} ${item.name}") },
        text = {
            Column {
                Text("Chemin : ${item.file.absolutePath}")
                Text("Type : ${if (item.isDirectory) "Dossier" else item.extension.ifEmpty { "Fichier" }}")
                Text(
                    "Taille : ${
                        humanReadableSize(
                            if (item.isDirectory) FileOperations.folderSize(item.file) else item.size()
                        )
                    }"
                )
                Text("Modifie le : ${formatDate(item.lastModified)}")
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) { Text("Fermer") }
        }
    )
}
