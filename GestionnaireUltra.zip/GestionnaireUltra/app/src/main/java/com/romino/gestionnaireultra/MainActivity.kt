package com.romino.gestionnaireultra

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.viewmodel.compose.viewModel
import com.romino.gestionnaireultra.ui.FileListScreen
import com.romino.gestionnaireultra.ui.GestionnaireUltraTheme
import com.romino.gestionnaireultra.ui.ImageViewerScreen
import com.romino.gestionnaireultra.ui.StorageInfoScreen
import com.romino.gestionnaireultra.ui.TextEditorScreen
import java.io.File

sealed class Screen {
    object FileList : Screen()
    data class TextEditor(val file: File) : Screen()
    data class ImageViewer(val file: File) : Screen()
    object StorageInfo : Screen()
}

// ---- Diagnostic temporaire : capture le crash au lieu de fermer l'appli ----
private object CrashLog {
    private const val PREFS = "crash_log"
    private const val KEY = "last_crash"

    fun install(context: Context) {
        val prefs = context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val previousHandler = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { thread, throwable ->
            try {
                prefs.edit().putString(KEY, throwable.stackTraceToString()).commit()
            } catch (_: Throwable) {
                // ignore, on ne veut pas planter dans le gestionnaire de crash lui-meme
            }
            previousHandler?.uncaughtException(thread, throwable)
                ?: android.os.Process.killProcess(android.os.Process.myPid())
        }
    }

    fun readAndClear(context: Context): String? {
        val prefs = context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val value = prefs.getString(KEY, null)
        if (value != null) prefs.edit().remove(KEY).apply()
        return value
    }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        CrashLog.install(this)
        setContent {
            GestionnaireUltraTheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    val context = LocalContext.current
                    var crashTrace by remember { mutableStateOf(CrashLog.readAndClear(context)) }
                    if (crashTrace != null) {
                        CrashScreen(trace = crashTrace!!, onDismiss = { crashTrace = null })
                    } else {
                        AppRoot()
                    }
                }
            }
        }
    }
}

@Composable
fun CrashScreen(trace: String, onDismiss: () -> Unit) {
    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        Text(
            "L'appli a plante au dernier lancement. Voici le detail (copie-le et envoie-le) :",
            style = MaterialTheme.typography.titleMedium
        )
        Spacer(modifier = Modifier.height(12.dp))
        Box(modifier = Modifier.weight(1f).verticalScroll(rememberScrollState())) {
            SelectionContainer {
                Text(trace, style = MaterialTheme.typography.bodySmall)
            }
        }
        Spacer(modifier = Modifier.height(12.dp))
        Button(onClick = onDismiss) { Text("Continuer vers l'appli") }
    }
}

private fun checkStoragePermission(context: Context): Boolean {
    return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
        Environment.isExternalStorageManager()
    } else {
        ContextCompat.checkSelfPermission(
            context, android.Manifest.permission.WRITE_EXTERNAL_STORAGE
        ) == PackageManager.PERMISSION_GRANTED
    }
}

@Composable
fun AppRoot() {
    val context = LocalContext.current
    var hasPermission by remember { mutableStateOf(checkStoragePermission(context)) }

    val legacyPermissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { result ->
        hasPermission = result.values.all { it } || checkStoragePermission(context)
    }

    val manageStorageLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) {
        hasPermission = checkStoragePermission(context)
    }

    if (!hasPermission) {
        PermissionScreen(onRequestPermission = {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                try {
                    val intent = Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION).apply {
                        data = Uri.parse("package:${context.packageName}")
                    }
                    manageStorageLauncher.launch(intent)
                } catch (e: Exception) {
                    manageStorageLauncher.launch(Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION))
                }
            } else {
                legacyPermissionLauncher.launch(
                    arrayOf(
                        android.Manifest.permission.READ_EXTERNAL_STORAGE,
                        android.Manifest.permission.WRITE_EXTERNAL_STORAGE
                    )
                )
            }
        })
    } else {
        val viewModel: FileManagerViewModel = viewModel()
        var screen by remember { mutableStateOf<Screen>(Screen.FileList) }

        when (val current = screen) {
            is Screen.FileList -> FileListScreen(
                viewModel = viewModel,
                onOpenText = { screen = Screen.TextEditor(it) },
                onOpenImage = { screen = Screen.ImageViewer(it) },
                onOpenStorageInfo = { screen = Screen.StorageInfo }
            )
            is Screen.TextEditor -> TextEditorScreen(
                file = current.file,
                onBack = { screen = Screen.FileList }
            )
            is Screen.ImageViewer -> ImageViewerScreen(
                file = current.file,
                onBack = { screen = Screen.FileList }
            )
            is Screen.StorageInfo -> StorageInfoScreen(
                viewModel = viewModel,
                onBack = { screen = Screen.FileList }
            )
        }
    }
}

@Composable
fun PermissionScreen(onRequestPermission: () -> Unit) {
    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.padding(32.dp)
        ) {
            Text("\uD83D\uDCC2", style = MaterialTheme.typography.displayLarge)
            Spacer(modifier = Modifier.height(16.dp))
            Text(
                "Gestionnaire Ultra a besoin d'acceder a vos fichiers pour fonctionner.",
                style = MaterialTheme.typography.bodyLarge,
                textAlign = TextAlign.Center
            )
            Spacer(modifier = Modifier.height(24.dp))
            Button(onClick = onRequestPermission) {
                Text("Autoriser l'acces aux fichiers")
            }
        }
    }
}
