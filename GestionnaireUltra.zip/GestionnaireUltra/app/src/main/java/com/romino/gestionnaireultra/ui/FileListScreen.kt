package com.romino.gestionnaireultra.ui

import android.content.Context
import android.content.Intent
import android.webkit.MimeTypeMap
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Checkbox
import androidx.compose.material3.DrawerValue
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.ListItem
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalDrawerSheet
import androidx.compose.material3.ModalNavigationDrawer
import androidx.compose.material3.NavigationDrawerItem
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.rememberDrawerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.content.FileProvider
import com.romino.gestionnaireultra.FileCategory
import com.romino.gestionnaireultra.FileItem
import com.romino.gestionnaireultra.FileManagerViewModel
import com.romino.gestionnaireultra.FileOperations
import com.romino.gestionnaireultra.SortMode
import com.romino.gestionnaireultra.category
import com.romino.gestionnaireultra.emoji
import com.romino.gestionnaireultra.formatDate
import com.romino.gestionnaireultra.humanReadableSize
import java.io.File

@OptIn(ExperimentalFoundationApi::class, ExperimentalMaterial3Api::class)
@Composable
fun FileListScreen(
    viewModel: FileManagerViewModel,
    onOpenText: (File) -> Unit,
    onOpenImage: (File) -> Unit,
    onOpenStorageInfo: () -> Unit
) {
    val context = LocalContext.current
    var drawerOpen by remember { mutableStateOf(false) }
    var showNewFolderDialog by remember { mutableStateOf(false) }
    var showNewFileDialog by remember { mutableStateOf(false) }
    var showZipNameDialog by remember { mutableStateOf(false) }
    var showSortMenu by remember { mutableStateOf(false) }
    var showFabMenu by remember { mutableStateOf(false) }
    var renameTarget by remember { mutableStateOf<File?>(null) }
    var propertiesTarget by remember { mutableStateOf<FileItem?>(null) }
    var searchResults by remember { mutableStateOf<List<FileItem>?>(null) }

    val selectionMode = viewModel.selection.isNotEmpty()
    val displayedItems = searchResults ?: viewModel.items

    ModalNavigationDrawer(
        drawerState = rememberDrawerState(if (drawerOpen) DrawerValue.Open else DrawerValue.Closed),
        drawerContent = {
            ModalDrawerSheet {
                Text(
                    "Gestionnaire Ultra",
                    style = MaterialTheme.typography.titleLarge,
                    modifier = Modifier.padding(16.dp)
                )
                HorizontalDivider()
                NavigationDrawerItem(
                    label = { Text("Stockage interne") },
                    selected = false,
                    icon = { Text("\uD83C\uDFE0") },
                    onClick = {
                        viewModel.navigateToRoot()
                        drawerOpen = false
                    },
                    modifier = Modifier.padding(horizontal = 12.dp)
                )
                NavigationDrawerItem(
                    label = { Text("Informations de stockage") },
                    selected = false,
                    icon = { Text("\u2139\uFE0F") },
                    onClick = {
                        drawerOpen = false
                        onOpenStorageInfo()
                    },
                    modifier = Modifier.padding(horizontal = 12.dp)
                )
                HorizontalDivider()
                Text(
                    "Favoris",
                    style = MaterialTheme.typography.labelLarge,
                    modifier = Modifier.padding(16.dp, 8.dp)
                )
                viewModel.favorites.forEach { fav ->
                    NavigationDrawerItem(
                        label = { Text(fav.name.ifEmpty { fav.absolutePath }) },
                        selected = false,
                        icon = { Text("\u2B50") },
                        onClick = {
                            viewModel.loadDirectory(fav)
                            drawerOpen = false
                        },
                        modifier = Modifier.padding(horizontal = 12.dp)
                    )
                }
            }
        }
    ) {
        Scaffold(
            topBar = {
                Column {
                    TopAppBar(
                        title = {
                            if (selectionMode) {
                                Text("${viewModel.selection.size} selectionne(s)")
                            } else {
                                Text(
                                    viewModel.currentDir.name.ifEmpty { "Stockage interne" },
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        },
                        navigationIcon = {
                            if (selectionMode) {
                                IconButton(onClick = { viewModel.clearSelection() }) {
                                    Text("\u2715")
                                }
                            } else {
                                IconButton(onClick = { drawerOpen = true }) {
                                    Text("\u2630")
                                }
                            }
                        },
                        actions = {
                            if (selectionMode) {
                                IconButton(onClick = { viewModel.copySelectedToClipboard() }) {
                                    Text("\uD83D\uDCCB")
                                }
                                IconButton(onClick = { viewModel.cutSelectedToClipboard() }) {
                                    Text("\u2702\uFE0F")
                                }
                                if (viewModel.selection.size == 1) {
                                    IconButton(onClick = {
                                        renameTarget = viewModel.selectedFiles().first()
                                    }) {
                                        Text("\u270F\uFE0F")
                                    }
                                    IconButton(onClick = {
                                        propertiesTarget = viewModel.selectedFiles().firstOrNull()?.let { FileItem(it) }
                                    }) {
                                        Text("\u2139\uFE0F")
                                    }
                                }
                                IconButton(onClick = { showZipNameDialog = true }) {
                                    Text("\uD83D\uDDDC\uFE0F")
                                }
                                IconButton(onClick = { viewModel.deleteSelected() }) {
                                    Text("\uD83D\uDDD1\uFE0F")
                                }
                            } else {
                                IconButton(onClick = { showSortMenu = true }) {
                                    Text("\u2195\uFE0F")
                                }
                                DropdownMenu(expanded = showSortMenu, onDismissRequest = { showSortMenu = false }) {
                                    listOf(
                                        SortMode.NAME to "Nom",
                                        SortMode.DATE to "Date",
                                        SortMode.SIZE to "Taille",
                                        SortMode.TYPE to "Type"
                                    ).forEach { (mode, label) ->
                                        DropdownMenuItem(
                                            text = { Text(label) },
                                            onClick = {
                                                viewModel.sortMode = mode
                                                viewModel.refresh()
                                                showSortMenu = false
                                            }
                                        )
                                    }
                                    HorizontalDivider()
                                    DropdownMenuItem(
                                        text = { Text(if (viewModel.sortAscending) "Ordre decroissant" else "Ordre croissant") },
                                        onClick = {
                                            viewModel.sortAscending = !viewModel.sortAscending
                                            viewModel.refresh()
                                            showSortMenu = false
                                        }
                                    )
                                    DropdownMenuItem(
                                        text = { Text(if (viewModel.showHidden) "Masquer fichiers caches" else "Afficher fichiers caches") },
                                        onClick = {
                                            viewModel.showHidden = !viewModel.showHidden
                                            viewModel.refresh()
                                            showSortMenu = false
                                        }
                                    )
                                }
                                IconButton(onClick = { viewModel.toggleFavorite(viewModel.currentDir) }) {
                                    Text(if (viewModel.isFavorite(viewModel.currentDir)) "\u2B50" else "\u2606")
                                }
                                if (viewModel.clipboard != null) {
                                    IconButton(onClick = { viewModel.pasteClipboard() }) {
                                        Text("\uD83D\uDCE5")
                                    }
                                }
                            }
                        }
                    )
                    OutlinedTextField(
                        value = viewModel.searchQuery,
                        onValueChange = { query ->
                            viewModel.searchQuery = query
                            if (query.isBlank()) {
                                searchResults = null
                            } else {
                                viewModel.search(query) { results -> searchResults = results }
                            }
                        },
                        placeholder = { Text("Rechercher dans ce dossier...") },
                        leadingIcon = { Text("\uD83D\uDD0D") },
                        trailingIcon = {
                            if (viewModel.searchQuery.isNotEmpty()) {
                                IconButton(onClick = {
                                    viewModel.searchQuery = ""
                                    searchResults = null
                                }) {
                                    Text("\u2715")
                                }
                            }
                        },
                        singleLine = true,
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 12.dp, vertical = 4.dp)
                    )
                    Text(
                        text = viewModel.currentDir.absolutePath,
                        style = MaterialTheme.typography.labelSmall,
                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp),
                        maxLines = 1
                    )
                }
            },
            floatingActionButton = {
                if (!selectionMode) {
                    Column(horizontalAlignment = Alignment.End) {
                        if (showFabMenu) {
                            SmallFabAction(emoji = "\uD83D\uDCC1", label = "Nouveau dossier") {
                                showFabMenu = false
                                showNewFolderDialog = true
                            }
                            Spacer(modifier = Modifier.height(8.dp))
                            SmallFabAction(emoji = "\uD83D\uDCC4", label = "Nouveau fichier") {
                                showFabMenu = false
                                showNewFileDialog = true
                            }
                            Spacer(modifier = Modifier.height(8.dp))
                        }
                        FloatingActionButton(onClick = { showFabMenu = !showFabMenu }) {
                            Text(if (showFabMenu) "\u2715" else "\u2795")
                        }
                    }
                }
            }
        ) { padding ->
            Box(modifier = Modifier.padding(padding)) {
                Column(modifier = Modifier.fillMaxSize()) {
                    if (!selectionMode) {
                        AssistChip(
                            onClick = { viewModel.navigateUp() },
                            label = { Text("\u2B06\uFE0F Dossier parent") },
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 4.dp)
                        )
                    }
                    if (viewModel.isLoading) {
                        LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
                    }
                    if (displayedItems.isEmpty() && !viewModel.isLoading) {
                        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                            Text("Ce dossier est vide", style = MaterialTheme.typography.bodyLarge)
                        }
                    } else {
                        LazyColumn(modifier = Modifier.fillMaxSize()) {
                            items(displayedItems, key = { it.file.absolutePath }) { item ->
                                FileRow(
                                    item = item,
                                    selected = viewModel.selection.contains(item.file.absolutePath),
                                    selectionMode = selectionMode,
                                    onClick = {
                                        when {
                                            selectionMode -> viewModel.toggleSelect(item)
                                            item.isDirectory -> {
                                                viewModel.loadDirectory(item.file)
                                                searchResults = null
                                                viewModel.searchQuery = ""
                                            }
                                            else -> openFile(item.file, context, onOpenText, onOpenImage) { zip ->
                                                viewModel.extractZip(zip)
                                            }
                                        }
                                    },
                                    onLongClick = { viewModel.toggleSelect(item) }
                                )
                            }
                        }
                    }
                }
            }
        }
    }

    if (showNewFolderDialog) {
        NameInputDialog(
            title = "Nouveau dossier",
            onConfirm = { viewModel.createFolder(it) },
            onDismiss = { showNewFolderDialog = false }
        )
    }
    if (showNewFileDialog) {
        NameInputDialog(
            title = "Nouveau fichier",
            onConfirm = { viewModel.createNewFile(it) },
            onDismiss = { showNewFileDialog = false }
        )
    }
    if (showZipNameDialog) {
        NameInputDialog(
            title = "Nom de l'archive",
            initialValue = "archive.zip",
            onConfirm = { viewModel.compressSelected(it) },
            onDismiss = { showZipNameDialog = false }
        )
    }
    renameTarget?.let { file ->
        NameInputDialog(
            title = "Renommer",
            initialValue = file.name,
            onConfirm = { viewModel.renameFile(file, it) },
            onDismiss = { renameTarget = null }
        )
    }
    propertiesTarget?.let { item ->
        PropertiesDialog(item = item, onDismiss = { propertiesTarget = null })
    }
}

@Composable
private fun SmallFabAction(emoji: String, label: String, onClick: () -> Unit) {
    ExtendedFloatingActionButton(
        onClick = onClick,
        icon = { Text(emoji) },
        text = { Text(label) }
    )
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun FileRow(
    item: FileItem,
    selected: Boolean,
    selectionMode: Boolean,
    onClick: () -> Unit,
    onLongClick: () -> Unit
) {
    val category = item.category()
    Column(modifier = Modifier.combinedClickable(onClick = onClick, onLongClick = onLongClick)) {
        ListItem(
            headlineContent = { Text(item.name, maxLines = 1) },
            supportingContent = {
                Text(
                    if (item.isDirectory) "${item.childCount()} element(s)"
                    else "${humanReadableSize(item.size())} \u2022 ${formatDate(item.lastModified)}"
                )
            },
            leadingContent = {
                if (selectionMode) {
                    Checkbox(checked = selected, onCheckedChange = { onClick() })
                } else {
                    Text(category.emoji(), style = MaterialTheme.typography.headlineSmall)
                }
            }
        )
        HorizontalDivider()
    }
}

private fun openFile(
    file: File,
    context: Context,
    onOpenText: (File) -> Unit,
    onOpenImage: (File) -> Unit,
    onExtractZip: (File) -> Unit
) {
    val item = FileItem(file)
    when (item.category()) {
        FileCategory.TEXT -> if (FileOperations.isTextReadable(file)) onOpenText(file) else openWithExternalApp(file, context)
        FileCategory.IMAGE -> onOpenImage(file)
        FileCategory.ARCHIVE -> if (item.extension == "zip") onExtractZip(file) else openWithExternalApp(file, context)
        else -> openWithExternalApp(file, context)
    }
}

private fun openWithExternalApp(file: File, context: Context) {
    try {
        val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
        val mime = MimeTypeMap.getSingleton().getMimeTypeFromExtension(file.extension) ?: "*/*"
        val intent = Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(uri, mime)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        context.startActivity(Intent.createChooser(intent, "Ouvrir avec"))
    } catch (e: Exception) {
        // Aucune application disponible pour ouvrir ce fichier
    }
}
